var localizedStrings = new Object;

localizedStrings['Done'] = 'Done';
localizedStrings['Refresh'] = 'Refresh:';
localizedStrings['ZIP'] = 'ZIP:';
localizedStrings['Delivercode'] = 'Delivercode:';
localizedStrings['StatusText'] = 'Please configure Zip and Delivercode';
localizedStrings['Hour_1'] = '1 Hour';
localizedStrings['Hour_3'] = '3 Hours';
localizedStrings['Hour_6'] = '6 Hours';
localizedStrings['Hour_12'] = '12 Hours';
localizedStrings['Hour_24'] = '24 Hours';
