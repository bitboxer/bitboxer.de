var error = false;
var timerId = 0;

function load()
{
	setupParts();
	refreshWidget();
	initWidget();
}

function initWidget() {
	refresh.innerHTML = 
		"<option value=\"1\">"+localizedStrings["Hour_1"]+"</option>"+
		"<option value=\"3\">"+localizedStrings["Hour_3"]+"</option>"+
		"<option value=\"6\">"+localizedStrings["Hour_6"]+"</option>"+
		"<option value=\"12\">"+localizedStrings["Hour_12"]+"</option>"+
		"<option value=\"24\">"+localizedStrings["Hour_24"]+"</option>";
}

function remove()
{
	// your widget has just been removed from the layer
	// remove any preferences as needed
	// widget.setPreferenceForKey(null, createInstancePreferenceKey("your-key"));
}

function hide()
{
	// your widget has just been hidden stop any timers to
	// prevent cpu usage
}

function show()
{
	// your widget has just been shown.  restart any timers
	// and adjust your interface as needed
	if (error)
		refreshWidget();
}

function showBack(event)
{
	// your widget needs to show the back

	var front = document.getElementById("front");
	var back = document.getElementById("back");

	if (window.widget)
		widget.prepareForTransition("ToBack");

	front.style.display="none";
	back.style.display="block";
	
	if (window.widget)
		setTimeout('widget.performTransition();', 0);
}

function showFront(event)
{
	// your widget needs to show the front

	var front = document.getElementById("front");
	var back = document.getElementById("back");

	if (window.widget)
		widget.prepareForTransition("ToFront");

	front.style.display="block";
	back.style.display="none";
	
	if (window.widget)
		setTimeout('widget.performTransition();', 0);

	refreshWidget();
}

if (window.widget)
{
	widget.onremove = remove;
	widget.onhide = hide;
	widget.onshow = show;
}

function refreshWidget() 
{
	if(timerId) {
      clearTimeout(timerId);
	}
	
	if (delivercode.value != "" && postal.value != "") {
		var url = "http://nolp.dhl.de/nextt-online-public/report_popup.jsp?lang=de&zip="
		url += escape(postal.value) + "&idc=" + delivercode.value;
		req = new XMLHttpRequest();
		req.onreadystatechange = processReqChange;
		req.open("GET", url, true);
		req.send("");

		timerId = setTimeout("refreshWidget()", refresh.value * 1000 * 60 * 60);
	} else {
		result.innerHTML = localizedStrings["StatusText"];
	}
	
}

function processReqChange() {
	// only if req shows "loaded"
    if (req.readyState == 4) {
        // only if "OK"
		if (req.status == 200) {
			var suche = /<td[ colspan="2"]* class="ListEvenLine">(.*)<\/td>/g;
			var text = "";
			
			while (ergebnis = suche.exec(req.responseText)) {
				text += ergebnis[1] + "<br/>";
			}
			
			result.innerHTML = text;
		  } else {
			result.innerHTML = "<strong>Fehler.</strong>";
            alert("There was a problem retrieving the XML data:\n" +
                req.statusText);
			error = true;
        }
    }
}