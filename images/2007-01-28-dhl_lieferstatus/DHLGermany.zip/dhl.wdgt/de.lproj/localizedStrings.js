var localizedStrings = new Object;

localizedStrings['Done'] = 'Fertig';
localizedStrings['Refresh'] = 'Aktualisieren:';
localizedStrings['ZIP'] = 'PLZ:';
localizedStrings['Delivercode'] = 'Sendungs-nummer:';
localizedStrings['StatusText'] = 'Bitte PLZ/Sendungsnummer einstellen...';
localizedStrings['Hour_1'] = '1 Stunde';
localizedStrings['Hour_3'] = '3 Stunden';
localizedStrings['Hour_6'] = '6 Stunden';
localizedStrings['Hour_12'] = '12 Stunden';
localizedStrings['Hour_24'] = '24 Stunden';
