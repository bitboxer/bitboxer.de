<?php
/**
 * This file creates social bookmarking links
 *
 * Original version @copyright (c)2006 Bodo Tasche
 *
 * b2evolution - {@link http://b2evolution.net/}
 * Released under GNU GPL License - {@link http://b2evolution.net/about/license.html}
 * @copyright (c)2003-2005 by Francois PLANQUE - {@link http://fplanque.net/}
 *
 * @package plugins
 * @license http://b2evolution.net/about/license.html GNU General Public License (GPL) 
 */
if( !defined('EVO_MAIN_INIT') ) die( 'Please, do not access this page directly.' );


/**
 * social bookmarking Plugin
 *
  * @package plugins
 */
class socialbookmark_plugin extends Plugin
{
  /**
   * Variables below MUST be overriden by plugin implementations,
   * either in the subclass declaration or in the subclass constructor.
   */
  var $code = 'socialbookmark';
  var $priority = 50;
  var $version = '1.0';
  var $author = 'Bodo Tasche';
  var $help_url = '';
  var $apply_rendering = 'stealth';
  var $group = 'rendering';

  /**
   * @deprecated just a wrapper for 1.8.x
   */
  function socialbookmark_plugin()
  {
    $this->PluginInit();
  }

  /**
   * Init
   */
  function PluginInit()
  {
    $this->name = $this->T_('Social Bookmarks');
    $this->short_desc = $this->T_('Adds Links to social bookmark services');
    $this->long_desc = $this->T_('This Plugin creates links to social bookmark services.');
  }

  /*
   * Event handler: Called during the display of the Skins's Html Head section.
   *
   * @param array Associative array of parameters
   * @return boolean did we do something?
         */
  function SkinBeginHtmlHead() {
    echo "<!-- SocialBookmarking Script-->";
    echo "<script type=\"text/javascript\">\n";
    echo "function ".$this->code."_over(text, id) {\n";
	echo "if (text == '') {\n";
    echo "text = '...';\n";
	echo "} else {\n";
	echo "text='<strong>'+text+'</strong>';\n";
	echo "}\n";
	echo "document.getElementById('".$this->code."_text_'+id).innerHTML=text;\n";
    echo "}\n";
    echo "</script>\n";
    return true;
  }


  function createSocialLinks(& $params) {
    global $plugins_url;

    $url = urlencode($params['Item']->get_permanent_url());
    $title=urlencode(utf8_encode($params['Item']->title));

    $ret = "<p class=\"small\">Diesen Artikel bookmarken bei <span id=\"".$this->code."_text_".$params['Item']->ID."\">...</span></p>";

    $ret .= "\t<a href=\"http://digg.com/submit?phase=2&url=".$url."&title=".$title."\"\" onmouseover=\"".$this->code."_over('digg', '".$params['Item']->ID."');\" onmouseout=\"".$this->code."_over('', '".$params['Item']->ID."');\"><img src=\"".$plugins_url.$this->classname."/icons/digg.gif\"/></a>";

    $ret .= "\t<a href=\"http://del.icio.us/post?url=".$url."&title=".$title."\" onmouseover=\"".$this->code."_over('del.icio.us', '".$params['Item']->ID."');\" onmouseout=\"".$this->code."_over('', '".$params['Item']->ID."');\"><img src=\"".$plugins_url.$this->classname."/icons/delicious.gif\"/></a>";

    $ret .= "\t<a href=\"http://www.mister-wong.de/index.php?action=addurl&bm_url=".$url."&bm_description=".$title."\" onmouseover=\"".$this->code."_over('Mister Wong', '".$params['Item']->ID."');\" onmouseout=\"".$this->code."_over('', '".$params['Item']->ID."');\"><img src=\"".$plugins_url.$this->classname."/icons/mrwong.gif\"/></a>";

    $ret .= "\t<a href=\"http://www.google.com/bookmarks/mark?op=add&hl=de&bkmk=".$url."&title=".$title."\" onmouseover=\"".$this->code."_over('google', '".$params['Item']->ID."');\" onmouseout=\"".$this->code."_over('', '".$params['Item']->ID."');\"><img src=\"".$plugins_url.$this->classname."/icons/google.gif\"/></a>";

    $ret .= "\t<a href=\"http://www.furl.net/storeIt.jsp?u=".$url."&t=".$title."\" onmouseover=\"".$this->code."_over('Furl', '".$params['Item']->ID."');\" onmouseout=\"".$this->code."_over('', '".$params['Item']->ID."');\"><img src=\"".$plugins_url.$this->classname."/icons/furl.gif\"/></a>";

    $ret .= "\t<a href=\"http://www.blinklist.com/index.php?Action=Blink/addblink.php&Description=&Url=".$url."&Title=".$title."\" onmouseover=\"".$this->code."_over('BlinkList', '".$params['Item']->ID."');\" onmouseout=\"".$this->code."_over('', '".$params['Item']->ID."');\"><img src=\"".$plugins_url.$this->classname."/icons/blinklist.gif\"/></a>";

    $ret .= "\t<a href=\"http://myweb2.search.yahoo.com/myresults/bookmarklet?u=".$url."&t=".$title."\" onmouseover=\"".$this->code."_over('Yahoo', '".$params['Item']->ID."');\" onmouseout=\"".$this->code."_over('', '".$params['Item']->ID."');\"><img src=\"".$plugins_url.$this->classname."/icons/yahoo.gif\"/></a>";

    $ret .= "\t<a href=\"http://yigg.de/neu?exturl=".$url."&exttitle=".$title."\" onmouseover=\"".$this->code."_over('YiGG', '".$params['Item']->ID."');\" onmouseout=\"".$this->code."_over('', '".$params['Item']->ID."');\"><img src=\"".$plugins_url.$this->classname."/icons/yigg.gif\"/></a>";

    $ret .= "\t<a href=\"http://www.folkd.com/submit/page/".$url."\" onmouseover=\"".$this->code."_over('Folkd', '".$params['Item']->ID."');\" onmouseout=\"".$this->code."_over('', '".$params['Item']->ID."');\"><img src=\"".$plugins_url.$this->classname."/icons/folkd.gif\"/></a>";

    $ret .= "\t<a href=\"http://linkarena.com/bookmarks/addlink/?url=".$url."&title=".$title."&desc=&tags=\" onmouseover=\"".$this->code."_over('Linkarena', '".$params['Item']->ID."');\" onmouseout=\"".$this->code."_over('', '".$params['Item']->ID."');\"><img src=\"".$plugins_url.$this->classname."/icons/linkarena.gif\"/></a>";

    $ret .= "\t<a href=\"http://beta.oneview.de:80/quickadd/neu/addBookmark.jsf?URL=".$url."&title=".$title."\" onmouseover=\"".$this->code."_over('oneview', '".$params['Item']->ID."');\" onmouseout=\"".$this->code."_over('', '".$params['Item']->ID."');\"><img src=\"".$plugins_url.$this->classname."/icons/oneview.gif\"/></a>";

    return $ret;
  }

  /**
   * Event handler: SkinTag
   *
   * @param array Associative array of parameters. Valid keys are:
   *        - 'css_class': CSS class for the DIV container (Default: plugin code/'evo_categorydescriptor')
   * @return boolean did we display?
   */
  function SkinTag( & $params )
  {
    global $disp;

    if( ! ( $this->Settings->get( 'show_always' ) || (($disp == 'posts') && ($s == ''))) )
    { // no displaying:
      return false;
    }

    if( ! isset($this->code) )
      $this->code = $this->code;

    echo "\n<div class=\"".$this->code."_item\">\n";
    echo $this->createSocialLinks($params);
    echo "\n</div>\n";

    return true;
  }

  /**
   * Event handler: Called when displaying item/post contents as HTML.
   *
   * Note: return value is ignored. You have to change $params['content'].
   *
   * @see Plugin::RenderItemAsHtml(()
   */
   function RenderItemAsHtml( & $params ) {
        $params['data'] .= "\n<div class=\"".$this->code."_item\">\n";
        $params['data'] .= $this->createSocialLinks($params);
        $params['data'] .= "\n</div>\n";

        return true;
    }

    /**
     * Event handler: Called as action just before updating the {@link Plugin::Settings plugin's settings}.
     *
     * The "regular" settings from {@link GetDefaultSettings()} have been set into
     * {@link Plugin::Settings}, but get saved into DB after this method has been called.
     *
     * Use this to catch custom input fields from {@link PluginSettingsEditDisplayAfter()} or
     * add notes/errors through {@link Plugin::msg()}.
     *
     * If you want to modify plugin events (see {@link Plugin::enable_event()} and
     * {@link Plugin::disable_event()}), you should use {@link Plugin::BeforeEnable()}, because Plugin
     * events get saved (according to the edit settings screen) after this event.
     *
     * @return false|NULL Return false to prevent the settings from being updated to DB.
     */
    function PluginSettingsUpdateAction() {
        global $DB;
        $DB->query('DELETE FROM T_item__prerendering WHERE 1');
        return true;
    }
}
?>
