<?php
/**
 * This file implements a simple tag cloud.
 *
 * Original version @copyright (c)2006 Bodo Tasche
 *
 * b2evolution - {@link http://b2evolution.net/}
 * Released under GNU GPL License - {@link http://b2evolution.net/about/license.html}
 * @copyright (c)2003-2005 by Francois PLANQUE - {@link http://fplanque.net/}
 *
 * @see http://manual.b2evolution.net/Tagcloud_plugin
 * @package plugins
 * @license http://www.opensource.org/licenses/gpl-license.php GNU General Public License (GPL)
 * @version $Id$
 */
if( !defined('EVO_MAIN_INIT') ) die( 'Please, do not access this page directly.' );


/**
 * Tag Cloud Plugin
 *
  * @package plugins
 */
class tagcloud_plugin extends Plugin
{
  /**
   * Variables below MUST be overriden by plugin implementations,
   * either in the subclass declaration or in the subclass constructor.
   */
  var $code = 'tagcloud';
  var $priority = 50;
  var $version = '2.5';
  var $author = 'Bodo Tasche';
  var $group = 'widget';

  var $apply_rendering = 'never';

  /**
   * @deprecated just a wrapper for 1.8.x
   */
  function tagcloud_plugin()
  {
    $this->PluginInit();
  }

  /**
   * Init
   */
  function PluginInit()
  {
    $this->name = $this->T_('Tag Cloud');
    $this->short_desc = $this->T_('Create a Tag Cloud');
    $this->long_desc = $this->T_('This plugin creates a Tag Cloud using all categories of the blog');
  }

  /**
   * Callback for sorting the category list by numbers, descending.
   */
  function sortHighestFirst($a, $b) {
    return $b['cat_postcount'] - $a['cat_postcount'];
  }

  /**
   * Callback for sorting the category list by numbers, ascending.
   */
  function sortHighestLast($a, $b) {
    return $a['cat_postcount'] - $b['cat_postcount'];
  }

  /**
   * Callback for sorting the category list alphabetically.
   */
  function sortAlphabetically($a, $b) {
    return strcasecmp($a['cat_name'], $b['cat_name']);
  }


  /**
   * Event handler: SkinTag
   *
   * @param array Associative array of parameters. Valid keys are:
   *        - 'css_class': CSS class for the DIV container (Default: plugin code/'evo_tagcloud')
   * @return boolean did we display?
   */
  function SkinTag( $params )
  {
    global $disp, $s;
    global $Blog;

    if( ! ( $this->Settings->get( 'show_always' ) || (($disp == 'posts') && ($s == ''))) )
    { // no displaying:
      return false;
    }

    if( ! isset($params['css_class']) )
      $params['css_class'] = $this->code;

    $sort_order = $this->Settings->get('sort_order');

    $cache_cats = $this->Settings->get('cache_cats');
    $cache_key = $Blog->ID; // cat_load_postcounts() acts in $Blog context
    if( is_array($cache_cats) && isset($cache_cats[$cache_key]) )
    { // data is cached already, assign it by reference:
      $cats = & $cache_cats[$cache_key]['cats'];
      $max  = & $cache_cats[$cache_key]['max'];
    }
    else
    { // generate data:
    	global $DB;
    
      if (!is_array($cache_cats)) {
        $cache_cats = array();
      }

      $this->debug_log('Generating cats data');

			$sql = ' SELECT count( * ) as cat_total, cat_ID, cat_name, cat_blog_ID FROM `evo_categories` c, evo_postcats p WHERE c.cat_ID = p.postcat_cat_ID GROUP BY cat_ID LIMIT 0 , 100 '; 

			$cache_categories = array();

  		if( $tags = $DB->get_results( $sql ) ) 
			{ 
  	  	foreach($tags as $tag) {
  	  		$cat = array();
  	  		$cat['cat_name'] = htmlentities($tag->cat_name );
  	    	$cat['cat_postcount'] = $tag->cat_total;
  	    	$cat['cat_blog_ID'] = $tag->cat_blog_ID;
  	    	$cache_categories[$tag->cat_ID] = $cat;
  	 		 }
  		}
  		
      // Transform b2evo's $cache_categories into own array (for caching)
      $cats = array();
      $max = 0;
      foreach($cache_categories as $id => $cat)
      {
      	
        if( ! $cat['cat_postcount'] )
        { // exclude, if no posts in it
          continue;
        }

        $cats[] = array('id' => $id, 'cat_postcount' => $cat['cat_postcount'], 'cat_name' => $cat['cat_name'], 'cat_blog_ID' => $cat['cat_blog_ID']);

        if ($cat['cat_postcount']>$max)
        { // new maximum postcount:
          $max = $cat['cat_postcount'];
        }
      }

      // Limit to max_items?
      if ($this->Settings->get('max_items') > 0) {
        usort($cats, array(&$this, 'sortHighestFirst'));
        $cats = array_slice($cats, 0, $this->Settings->get('max_items'));
      }

      // Sort:
      switch( $sort_order )
      {
        case 'alphabetical':
          usort($cats, array(&$this, 'sortAlphabetically'));
          break;
        case 'random':
          // gets shuffled always later
          break;
        case 'mostfirst':
          usort($cats, array(&$this, 'sortHighestFirst'));
          break;
        case 'mostlast':
          usort($cats, array(&$this, 'sortHighestLast'));
          break;
      }

      $cache_cats[$cache_key] = array( 'cats' => $cats, 'max' => $max );
      $this->Settings->set( 'cache_cats', $cache_cats );
      $this->Settings->dbupdate();
    }

    if( $sort_order == 'random' ) {
      shuffle($cats);
    }

    // DISPLAY:
    $fontmin = $this->Settings->get( 'font_min' );
    $fontdelta = $this->Settings->get( 'font_max' ) - $fontmin;

    echo '<div class="'.$params['css_class']."\">\n";

    if ($this->Settings->get( 'title') != '') {
      echo '<h1>'.$this->Settings->get('title').'</h1>\n';
    }

    echo '<p>'; // TODO: dh> I  think there should be no 'P', at least  by default. Maybe we could use a 'format' string here, where %s gets replaced with the generated data?

    foreach($cats as $id => $cat)
    {
      $num = $fontmin + round($fontdelta * ($cat['cat_postcount']*100/$max) / 100);

      echo '<span style="font-size:'.$num.'%">'
        .'<a href="'.url_add_param( $Blog->get('blogurl'), 'cat='.$cat['id'] )
					.'" title="'.htmlspecialchars(T_('Browse category')).'">'
				.$cat['cat_name'].'</a>'
        ."</span>\n";
    }

    echo "</p>\n</div>\n";

    return true;
  }

  /**
   * Define settings that the plugin uses/provides.
   */
  function GetDefaultSettings()
  {
    global $Settings;

    return array(
        'title' => array (
          'label' => $this->T_('Title'),
          'defaultvalue' => '',
          'note' => $this->T_('Shows a title above the tag cloud. If you leave this empty, no &lt;h1&gt; will be generated.')),
        'font_min' => array(
          'label' => $this->T_( 'Minimum Font Size' ),
          'defaultvalue' => 90,
          'note' => $this->T_('Minimum Font Size for the TagCloud (in percent)')),
        'font_max' => array(
          'label' => $this->T_( 'Maxmimum Font Size' ),
          'defaultvalue' => 300,
          'note' => $this->T_('Maximum Font Size for the TagCloud (in percent)')),
        'max_items' => array (
          'label' => $this->T_('Maximum Items to display'),
          'defaultvalue' => -1,
          'type' => 'integer',
          'note' => $this->T_('-1 to show all Items')),
        'sort_order' => array (
          'label' => $this->T_('Sort order'),
          'defaultvalue' => 'alphabetical',
          'type' => 'select',
          'options' => array (
              'alphabetical' => $this->T_('Alphabetically'),
              'random' => $this->T_('Random'),
              'mostfirst' => $this->T_('Most used first'),
              'mostlast' => $this->T_('Most used last') ),
          'note' => $this->T_('The order in which the tags are shown in the tag cloud')
        ),
        'show_always' => array (
          'label' => $this->T_('Show tag cloud everywhere'),
          'defaultvalue' => 0, // TODO: dh> change this to 1? With b2evo you are able to assign it as a widget
          'type' => 'checkbox',
          'note' => $this->T_('Shows the tag cloud on every page, even on details or search pages')
        ),

        'cache_cats' => array(
          'no_edit' => true, // used internally
          'type' => 'array', // so that it gets (un)serialized in 1.8.x
        ),
    );
  }


  /**
   * Delete cache if an item gets updated
   */
  function AfterItemUpdate()
  {
    $this->Settings->delete('cache_cats');
    $this->Settings->dbupdate();
  }


  /**
   * Delete cache if an item gets inserted
   */
  function AfterItemInsert()
  {
     $this->AfterItemUpdate();
  }


  /**
   * Delete cache if an item gets deleted
   */
  function AfterItemDelete()
  {
     $this->AfterItemUpdate();
  }


  /**
   * Settings get updated: delete our cache
   */
  function PluginSettingsUpdateAction()
  {
    $this->Settings->delete('cache_cats');
    // NOTE: dbupdate() gets called later on $Settings
  }


  /**
   * Delete the cache during upgrade. The format has changed in 2.02.
   */
  function PluginVersionChanged( & $params )
  {
    if( version_compare( $params['old_version'], '2.01', '<=' ) )
    {
      $this->Settings->delete('cache_cats');
      $this->Settings->dbupdate();
    }

    return true; // all OK
  }
}
?>
