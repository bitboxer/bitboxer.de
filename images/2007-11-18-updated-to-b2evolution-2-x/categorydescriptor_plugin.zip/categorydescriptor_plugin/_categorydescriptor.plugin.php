<?php
/**
 * This file implements a simple tag cloud.
 *
 * Original version @copyright (c)2006 Bodo Tasche
 *
 * b2evolution - {@link http://b2evolution.net/}
 * Released under GNU GPL License - {@link http://b2evolution.net/about/license.html}
 * @copyright (c)2003-2005 by Francois PLANQUE - {@link http://fplanque.net/}
 *
 * @todo Please add a license line. See http://forums.b2evolution.net//viewtopic.php?t=9923
 *
 * @package plugins
 */
if( !defined('EVO_MAIN_INIT') ) die( 'Please, do not access this page directly.' );


/**
 * Category Descriptor Plugin
 *
  * @package plugins
 */
class categorydescriptor_plugin extends Plugin
{
  /**
   * Variables below MUST be overriden by plugin implementations,
   * either in the subclass declaration or in the subclass constructor.
   */
  var $code = 'categorydescriptor';
  var $priority = 50;
  var $version = '1.5';
  var $author = 'Bodo Tasche';
  var $help_url = '';

  var $apply_rendering = 'stealth';

  /**
   * @deprecated just a wrapper for 1.8.x
   */
  function categorydescriptor_plugin()
  {
    $this->PluginInit();
  }

  /**
   * Init
   */
  function PluginInit()
  {
    $this->name = $this->T_('Category Descriptor');
    $this->short_desc = $this->T_('Shows a description if a category is selected.');
    $this->long_desc = $this->T_('This plugin shows a configurable description for a selected category.');
  }

  /**
   * Define settings that the plugin uses/provides.
   */
  function GetDefaultSettings()
  {
	global $Settings, $DB;
	
		$sql = 'SELECT cat_ID, cat_name FROM T_categories order by cat_name'; 
		
    $catarray = array();
	
		if( $tags = $DB->get_results( $sql ) ) 
		{ 
  	  foreach($tags as $tag) {
  	    $catarray['cat_'.$tag->cat_ID] = htmlentities($tag->cat_name );
   	 	}
		}
	
		return array(
			'category_descriptions' => array(
				'label' => T_('Descriptions for categories'),
				'note' => T_('Add a description for categories that are important to you.'),
				'type' => 'array',
				'entries' => array(
					'category' => array(
						'label' => T_('Category'),
						'note' => T_('Select a category'),
						'type' => 'select',
						'options' => $catarray
					),
					'description' => array(
                                        	'label' => $this->T_('Description'),
                                        	'defaultvalue' => '',
                                        	'note' => $this->T_('Description for the selected category'),
                                        	'size' => 50,
						'rows' => 10,
                                        	'type' => 'textarea'
					),
					'link' => array(
                                        	'label' => $this->T_('Link under posts'),
                                        	'defaultvalue' => '',
                                        	'note' => $this->T_('Put this text under each post that contains the category. If you want to create a link to this category, put the word into [[ ]].'),
                                        	'size' => 50,
						'rows' => 10,
                                        	'type' => 'textarea'
					)
				)
			)

    );
  }

  /**
   * Event handler: SkinTag
   *
   * @param array Associative array of parameters. Valid keys are:
   *        - 'css_class': CSS class for the DIV container (Default: plugin code/'evo_categorydescriptor')
   * @return boolean did we display?
   */
  function SkinTag( $params )
  {
    global $disp, $s, $cat;
    global $Blog; // for $cache_key

    if( ! ( $this->Settings->get( 'show_always' ) || (($disp == 'posts') && ($s == ''))) )
    { // no displaying:
      return false;
    }

    if( ! isset($params['css_class']) )
      $params['css_class'] = $this->code;

    if (isset($cat) && is_array($this->Settings->get('category_descriptions'))) {
      foreach($this->Settings->get('category_descriptions') as $catarray) {
        if ($catarray['category'] == 'cat_'.$cat) {
          echo "\n<div class=\"".$params['css_class']."\">\n";
          echo $catarray['description'];
          echo "\n</div>\n";
        }
      }
    }

    return true;
  }

    /**
     * Creates category-links
     */
    function createLink($string, $id) {
      global $Blog;

      $string = str_replace("[[", "<a href=\"".url_add_param( $Blog->get('blogurl'), 'cat='.$id)."\">", $string);
      $string = str_replace("]]", "</a>", $string);
      return $string;
    }


	/**
	 * Event handler: Called when displaying item/post contents as HTML.
	 *
	 * Note: return value is ignored. You have to change $params['content'].
	 *
	 * @see Plugin::RenderItemAsHtml(()
	 */
	function RenderItemAsHtml( & $params )
	{
        global $cache_postcats;

        if( ! isset($params['css_class']) )
          $params['css_class'] = $this->code;

        $id = $params['Item']->ID;
        $categoryIDs = $cache_postcats[$id];

        foreach( $categoryIDs as $cat_ID ) {
          foreach ($this->Settings->get('category_descriptions') as $catarray) {
            if ((strlen($catarray['link']) > 0) && ($catarray['category'] == 'cat_'.$cat_ID)) {
              $params['data'] .= "\n<div class=\"".$params['css_class']."_item\">\n";
              $params['data'] .= $this->createLink($catarray['link'], $cat_ID);
              $params['data'] .= "\n</div>\n";
            }
          }

        }

        return true;
	}

    /**
     * Event handler: Called as action just before updating the {@link Plugin::Settings plugin's settings}.
     *
     * The "regular" settings from {@link GetDefaultSettings()} have been set into
     * {@link Plugin::Settings}, but get saved into DB after this method has been called.
     *
     * Use this to catch custom input fields from {@link PluginSettingsEditDisplayAfter()} or
     * add notes/errors through {@link Plugin::msg()}.
     *
     * If you want to modify plugin events (see {@link Plugin::enable_event()} and
     * {@link Plugin::disable_event()}), you should use {@link Plugin::BeforeEnable()}, because Plugin
     * events get saved (according to the edit settings screen) after this event.
     *
     * @return false|NULL Return false to prevent the settings from being updated to DB.
     */
    function PluginSettingsUpdateAction() {
        global $DB;
        $DB->query('DELETE FROM T_items__prerendering WHERE 1');
        return true;
    }
}
?>
