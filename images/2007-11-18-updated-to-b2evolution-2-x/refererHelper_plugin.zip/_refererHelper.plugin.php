<?php
/**
 * This plugin shows a help text for specific referers.
 *
 * Original version @copyright (c)2006 Bodo Tasche
 *
 * b2evolution - {@link http://b2evolution.net/}
 * Released under GNU GPL License - {@link http://b2evolution.net/about/license.html}
 * @copyright (c)2003-2005 by Francois PLANQUE - {@link http://fplanque.net/}
 *
 * @todo Please add a license line. See http://forums.b2evolution.net//viewtopic.php?t=9923
 *
 * @package plugins
 */
if( !defined('EVO_MAIN_INIT') ) die( 'Please, do not access this page directly.' );


/**
 * Referer helper Plugin
 *
  * @package plugins
 */
class refererhelper_plugin extends Plugin
{
  /**
   * Variables below MUST be overriden by plugin implementations,
   * either in the subclass declaration or in the subclass constructor.
   */
  var $code = 'refererhelper';
  var $priority = 50;
  var $version = '1.0';
  var $author = 'Bodo Tasche';
  var $help_url = '';

  var $apply_rendering = 'none';

  /**
   * @deprecated just a wrapper for 1.8.x
   */
  function refererhelper_plugin()
  {
    $this->PluginInit();
  }

  /**
   * Init
   */
  function PluginInit()
  {
    $this->name = $this->T_('Referer Helper');
    $this->short_desc = $this->T_('Shows a help text for specific referers.');
    $this->long_desc = $this->T_('This plugin shows a configurable help text for referes such as Google Search Keywords, simple referers or IP\'s.');
  }

  /**
   * Define settings that the plugin uses/provides.
   */
  function GetDefaultSettings()
  {
	global $Settings;

	return array(
			'referer_descriptions' => array(
				'label' => T_('Descriptions for referers'),
				'note' => T_('Add a help text for each referer that is important to you.'),
				'type' => 'array',
				'entries' => array(
					'category' => array(
						'label' => T_('Type'),
						'note' => T_('Select a type'),
						'type' => 'select',
						'options' => array("ip" => "IP-Address", "search"=>"Search Query", "referer"=>"Referer URL")
					),
                    'value' => array (
                        'label' => $this->T_('Value'),
                        'defaultvalue' => '',
                        'note' => $this->T_('The IP, search query or referer.')),
					'description' => array(
                                        	'label' => $this->T_('Description'),
                                        	'defaultvalue' => '',
                                        	'note' => $this->T_('Description for the selected category'),
                                        	'size' => 50,
                    						'rows' => 10,
                                        	'type' => 'textarea'
					)
				)
			)

    );
  }

  function stats_search_keywords( $ref )
  {
        $kwout = '';
        if( ($pos_question = strpos( $ref, '?' )) == false )
        {
                return '['.T_('not a query - no params!').']';
        }
        $ref_params = explode( '&', substr( $ref, $pos_question+1 ) );
        foreach( $ref_params as $ref_param )
        {
                $param_parts = explode( '=', $ref_param );
                if( $param_parts[0] == 'q'
                                or $param_parts[0] == 'as_q'            // Google Advanced Search Query
                                or $param_parts[0] == 'query'
                                or $param_parts[0] == 'search'
                                or $param_parts[0] == 'p'
                                or $param_parts[0] == 'kw'
                                or $param_parts[0] == 'qs'
                                or $param_parts[0] == 'r'
                                or $param_parts[0] == 'rdata'                           // search.ke.voila.fr
                                or $param_parts[0] == 'su'                              // suche.web.de
                        )
                { // found "q" query parameter
                        $q = urldecode($param_parts[1]);
                        if( strpos( $q, 'Ã' ) !== false )               // fp> TODO: rewrite with in ASCII with a hex code
                        { // Probability that the string is UTF-8 encoded is very high, that'll do for now...
                                //echo "[UTF-8 decoding]";
                                $q = utf8_decode( $q );
                        }
                        $qwords = explode( ' ', $q );
                        foreach( $qwords as $qw )
                        {
                                $kwout .= $qw.' ';
                        }
                        return $kwout;
                }
        }
        return "";
  }


  /**
   * Event handler: SkinTag
   *
   * @param array Associative array of parameters. Valid keys are:
   *        - 'css_class': CSS class for the DIV container (Default: plugin code/'refererhelper')
   * @return boolean did we display?
   */
  function SkinTag( $params )
  {
    global $disp, $s, $cat, $Blog, $search_engines;

    if( ! isset($params['css_class']) )
      $params['css_class'] = $this->code;

    if (isset($_SERVER["HTTP_REFERER"]))
      $searchtext = strtolower($this->stats_search_keywords($_SERVER["HTTP_REFERER"]));
    else
      $searchtext = "";

    $referer_descs = $this->Settings->get('referer_descriptions');
    if (is_array($referer_descs)) {
	foreach($referer_descs as $refarray) {
		if (($refarray['category'] == 'ip') && ($_SERVER["REMOTE_ADDR"]==$refarray['value'])) {
			echo "\n<div class=\"".$params['css_class']."\">\n";
			echo $refarray['description'];
			echo "\n</div>\n";
		} else if (($refarray['category'] == 'referer') && (isset($_SERVER["HTTP_REFERER"]))){
			if (!(strpos(strtolower($_SERVER["HTTP_REFERER"]), strtolower($refarray['value']))===false)) {
				echo "\n<div class=\"".$params['css_class']."\">\n";
				echo $refarray['description'];
				echo "\n</div>\n";
			}
		} else if (($refarray['category'] == 'search')) {
			if (!(strpos($searchtext, strtolower($refarray['value']))===false)) {
				echo "\n<div class=\"".$params['css_class']."\">\n";
				echo $refarray['description'];
				echo "\n</div>\n";
			}
		}
	}
    }

    return true;
  }
}
?>
