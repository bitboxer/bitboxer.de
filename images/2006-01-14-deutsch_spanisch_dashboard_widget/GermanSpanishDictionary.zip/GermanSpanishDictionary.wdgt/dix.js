/*
 *	dix.osola.com Dashboard Widget
 *	
 *	Copyright 2006 Bodo Tasche
 *	http://www.wannawork.de
 */
var canvasWidth = 226;
var canvasHeight = 26;
var canvasOffsetLeft = 7;
var canvasOffsetTop = 5;
var edgeRadius = 12;

var URL_DIX = "http://dix.osola.com";
var URL_HOMEPAGE = "http://www.wannawork.de";

if(window.widget) {
	window.onblur = function(){
		onBlur();
		search.blur();
	};
	setTimeout("window.resizeTo(240, 50)", 100);
}

function drawFront() {
    back.style.visibility = "hidden";
    front.style.visibility = "visible";
	canvasHeight = 26;
	var context = canvas.getContext("2d");
	context.clearRect(0, 0, canvasWidth + canvasOffsetLeft * 2,
						canvasHeight + canvasOffsetTop * 2 + 20);

	createPath(context);
	context.save();
	context.setFillColor(0.0, 0.0, 0.0, 1.0);
	context.setShadow(0, 7, 10, 0.0, 0.5);
	context.fill();
	context.restore();

	context.save();
	createPath(context);
	context.fillStyle = context.createLinearGradient(0,0,0,canvasHeight);
	context.fillStyle.addColorStop(0, "#628dd3");
	context.fillStyle.addColorStop(1, "#466497");
	context.fill();
	context.restore();

	context.save();
	createPath(context);
	context.setStrokeColor("#466497", 1.0);
	context.setLineWidth(1.5);
	context.setLineCap("round");
	context.stroke();
	context.restore();
}

function drawBack() {
    front.style.visibility = "hidden";
    back.style.visibility = "visible";

	canvasHeight = 30;
	var context = canvas2.getContext("2d");

	context.clearRect(0, 0, canvasWidth + canvasOffsetLeft * 2,
						canvasHeight + canvasOffsetTop * 2 + 20);
	context.save();
	createPath(context);
	context.setFillColor(0.0, 0.0, 0.0, 1.0);
	context.setShadow(0, 7, 10, 0.0, 0.5);
	context.fill();
	context.restore();
	
	context.save();
	createPath(context);
	context.fillStyle = context.createLinearGradient(0,0,0,canvasHeight);
	context.fillStyle.addColorStop(0, "#628dd3");
	context.fillStyle.addColorStop(1, "#466497");
	context.fill();
	context.restore();

	context.save();
	createPath(context);
	context.setStrokeColor("#466497", 1.0);
	context.setLineWidth(1.5);
	context.setLineCap("round");
	context.stroke();
	context.restore();
}

function createPath(context) {
	context.beginPath();
	context.moveTo(canvasOffsetLeft + edgeRadius, canvasOffsetTop);
	context.arcTo(canvasOffsetLeft + canvasWidth, canvasOffsetTop,
					canvasOffsetLeft + canvasWidth, canvasOffsetTop + edgeRadius,
					edgeRadius);
	context.arcTo(canvasOffsetLeft + canvasWidth, canvasOffsetTop + canvasHeight,
					canvasOffsetLeft + canvasWidth - edgeRadius, canvasOffsetTop + canvasHeight,
					edgeRadius);
	context.arcTo(canvasOffsetLeft, canvasOffsetTop + canvasHeight,
					canvasOffsetLeft, canvasOffsetTop + canvasHeight - edgeRadius,
					edgeRadius);
	context.arcTo(canvasOffsetLeft, canvasOffsetTop,
					canvasOffsetLeft + edgeRadius, canvasOffsetTop,
					edgeRadius);
	context.closePath();
}

function onSearch() {
	if(search.value != "") {
		var url = "http://dix.osola.com/index.php?search="
		url += escape(search.value);
		if(window.widget) {
			widget.openURL(url);
		}
		else {
			alert(url);
		}
		search.value = "dix.osola.com";
		search.style.color = "#888888";
	}
}

function onFocus() {
	if(search.value == "dix.osola.com") {
		search.value = "";
		search.style.color = "#000000";
	}
}

function onBlur() {
	if(search.value == "") {
		search.value = "dix.osola.com";
		search.style.color = "#888888";
	}
}

function showBack() {
	exitflip();
    var front = document.getElementById("front");
    var back = document.getElementById("back");
    if(window.widget)
        widget.prepareForTransition("ToBack");       
    drawBack();
    if(window.widget)
        setTimeout('widget.performTransition();', 0);
}

function hideBack() {
    var front = document.getElementById("front");
    var back = document.getElementById("back");
    if (window.widget)
        widget.prepareForTransition("ToFront");
    drawFront();
    if (window.widget)
        setTimeout('widget.performTransition();', 0);
}

function showWannawork() {
	if(window.widget) {
		widget.openURL(URL_HOMEPAGE);
	}
	else {
		alert(URL_HOMEPAGE);
	}
}
